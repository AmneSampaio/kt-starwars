package cinema.starwars.kotlin.Starwars

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class StarwarsApplicationTests {

	@Test
	fun contextLoads() {
	}

}
